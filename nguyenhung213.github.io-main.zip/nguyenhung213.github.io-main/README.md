# Astray

A WebGL maze game built with Three.js and Box2dWeb. Play it here: http://wwwtyro.github.io/Astray/

### Launching

There are several ways to launch the game. Here is the simplest:

1. Clone or download the repository
2. Navigate to Astray's directory
3. Start 'python -m SimpleHTTPServer' in your shell (for python 3.0 and above type 'python -m http.server' in your shell)
4. Open 'localhost:8000' in your browser
5. Enjoy!
